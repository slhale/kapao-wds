.. _changelog:

**************
Full Changelog
**************

.. include:: ../CHANGES.rst
