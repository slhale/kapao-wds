:orphan:

.. include:: links.inc
.. _terminal_cast:

Terminal-cast of worked example
===============================

.. note::

    The commands used for creating a new environment in this example work
    only in the Anaconda python distribution. For other distributions use
    `virtualenvwrapper`_; see :ref:`virtual_envs` for details.

.. raw:: html

    <iframe src='http://asciinema.org/a/7003/raw?container_width=695&speed=4' width='700' height='800'></iframe>
