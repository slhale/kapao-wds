Mixins for added functionality
==============================

.. toctree::
    :maxdepth: 2

    ndslicing.rst
    ndarithmetic.rst
    ndio.rst
