.. currentmodule:: astropy.io.fits

Headers
-------

:class:`Header`
^^^^^^^^^^^^^^^

.. autoclass:: Header
   :members:
   :inherited-members:
   :undoc-members:
   :show-inheritance:
