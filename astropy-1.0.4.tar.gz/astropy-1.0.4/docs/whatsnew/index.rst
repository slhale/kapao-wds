=====================
Major Release History
=====================

.. toctree::
   :maxdepth: 1

   1.0
   0.4
   0.3
   0.2
   0.1
