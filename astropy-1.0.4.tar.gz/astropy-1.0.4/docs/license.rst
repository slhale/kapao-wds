********
Licenses
********

Astropy License
===============

Astropy is licensed under a 3-clause BSD style license:

.. include:: ../licenses/LICENSE.rst

Other Licenses
==============

Full licenses for third-party software astropy is derived from or included
with Astropy can be found in the ``'licenses/'`` directory of the source
code distribution.
